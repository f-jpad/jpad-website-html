function sendEmail(event) {
  event.preventDefault();
  var form = event.target;
  // Use the appropriate email service/library to send the email
  // Replace the placeholders with the actual email service/library code
  // Example using EmailJS:
  emailjs.sendForm('fabio_jpad', 'contact_form', form, 'X2B4-IImGeLfedn4a')
    .then(function(response) {
      console.log('Email sent successfully', response.text);
    })
    .catch(function(error) {
      console.log('Error sending email', error.text);
    });
}
